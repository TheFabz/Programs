package org.academiadecodigo.bootcamp56.rockpaperscissor;

public class Sandbox {

    public static void main(String[] args){

        Game new_game = new Game();

        new_game.startGame();
    }

}
